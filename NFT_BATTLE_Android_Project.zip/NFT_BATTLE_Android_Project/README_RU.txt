NFT BATTLE V26 — Android WebView project

Это исходный проект для сборки тестового APK, а не уже собранный APK.
Внутри app/src/main/assets/index.html лежит тестовая версия NFT BATTLE V26 (ID 1, без вкладки админки).

Как собрать APK:
1. Установи Android Studio с официального сайта developer.android.com/studio.
2. Распакуй ZIP в отдельную папку.
3. В Android Studio выбери Open и укажи папку NFT_BATTLE_Android_Project.
4. Дождись Gradle Sync. Если IDE предложит установить Android SDK Platform 35, согласись.
5. Для тестового APK выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
6. После сборки нажми Locate в уведомлении. Обычно файл будет в app/build/outputs/apk/debug/app-debug.apk.
7. Отправь APK тестеру. На его Android может потребоваться разрешить установку из выбранного приложения (например, файлового менеджера или Telegram).

Важно:
- APK debug-подписан для тестирования; это не публикация в Google Play и не гарантия прохождения модерации.
- Игра пока хранит прогресс локально на устройстве; общего онлайн-сервера и общего рейтинга между телефонами нет.
- В проект добавлена обработка выбора аватара через системный выбор изображения.
